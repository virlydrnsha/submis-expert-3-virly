Feature("Dislike Restaurant");
Scenario("showing empty Dislike one restaurant", async ({ I }) => {
  I.amOnPage("/");
  I.wait(10);
  I.seeElement(".content");
  I.seeElement(".list-restaurant");
  I.seeElement('.card');
  I.seeElement('.details');
  const firstRestaurant = locate("h4 a").first();
  I.click(firstRestaurant);
  I.wait(10);
  I.seeElement("#likeButton");
  I.click("#likeButton");

  I.amOnPage("#/favorite");
  I.seeElement(".list-restaurant");
  I.seeElement('.card');
  I.seeElement('.details');
  I.click(firstRestaurant);
  I.seeElement("#likeButton");
  I.click("#likeButton");
  I.amOnPage("#/favorite");
  I.seeElement(".content");
});
