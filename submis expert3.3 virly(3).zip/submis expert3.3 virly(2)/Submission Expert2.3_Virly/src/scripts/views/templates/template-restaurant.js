import CONFIG from '../../globals/config';

const createRestaurantDetailTemplate = (restaurant, foods, drinks, review) => `
    <h2 class="restaurant__title">${restaurant.name}</h2>
    <img class="restaurant__poster lazyload" src="${CONFIG.BASE_IMAGE_URL}${restaurant.pictureId}" alt="${restaurant.name}" crossorigin="anonymous"/>
    <div class="restaurant__info">
      <h3>Informasi</h3>
        <br>
        <h4>Kota : </h4>
        <p>${restaurant.city}</p>
        <br>
        <h4>Alamat : </h4>
        <p>${restaurant.address}</p>
        <br>
        <h4>Rating : </h4>
        <p>${restaurant.rating}</p>
        <br>
        <h4>Deskripsi</h4>
        <p>${restaurant.description}</p>
        <br>      
        <h4>Menu Makanan</h4>
        <p>${foods}</p>
        <br>
        <h4>Menu Minuman</h4>
        <p>${drinks}</p>
        <br>
        <h4>Ulasan Pelanggan</h4>
        <p>${review}</p>
    </div>
`;

const createRestaurantItemTemplate = (restaurant) => `
  <div class="card"> 
     <div class="card-img">
     <div class="city"> Kota ${restaurant.city}</div>
     <img class="lazyload" data-src="${CONFIG.BASE_IMAGE_URL}${restaurant.pictureId}" alt="${restaurant.name} crossorigin="anonymous"/>
     </div>
     <div class="details">
        <h4 class="card-details"><a href="${`/#/detail/${restaurant.id}`}">
            ${restaurant.name} </a>
        </h4>
        <p class="rating">
            Rating ⭐️: ${restaurant.rating}
        </p>
        <p class="card-desc">
            Description    : ${restaurant.description}
        </p>
        </div>
      </div>
`;

const createLikeButtonTemplate = () => `
  <button aria-label="like this restaurant" id="likeButton" class="like">
     <i class="fa fa-heart-o" aria-hidden="true"></i>
  </button>
`;

const createLikedButtonTemplate = () => `
  <button aria-label="unlike this restaurant" id="likeButton" class="like">
    <i class="fa fa-heart" aria-hidden="true"></i>
  </button>
`;

export {
  createRestaurantDetailTemplate,
  createRestaurantItemTemplate,
  createLikeButtonTemplate,
  createLikedButtonTemplate,
};
