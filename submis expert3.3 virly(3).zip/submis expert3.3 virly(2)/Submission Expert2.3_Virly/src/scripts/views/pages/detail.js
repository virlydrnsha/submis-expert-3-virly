import RestaurantDbSource from '../../data/restaurant-source';
import UrlParser from '../../routes/url-parser';
import LikeButtonInitiator from '../../utils/like-button-initiator';
import { createRestaurantDetailTemplate } from '../templates/template-restaurant';

const Detail = {
  async render() {
    return `
    <div class="container_detail">
    <a href="#content" class="skip-link">Skip to content</a>
    <section id="content" class="content">
      <div id="list-detail" class="list-detail">
      </div>
    </section>
    <div id="likeButtonContainer" class="like"></div>
</div>
      `;
  },

  async afterRender() {
    const url = UrlParser.parseActiveUrlWithoutCombiner();
    const restaurant = await RestaurantDbSource.detailRestaurants(url.id);
    const restaurantContainer = document.querySelector('#list-detail');
    const foods = await RestaurantDbSource.foodList();
    const drinks = await RestaurantDbSource.drinkList();
    const reviews = await RestaurantDbSource.customerReviews();

    // eslint-disable-next-line max-len
    restaurantContainer.innerHTML = createRestaurantDetailTemplate(restaurant.restaurant, foods, drinks, reviews);

    LikeButtonInitiator.init({
      likeButtonContainer: document.querySelector('#likeButtonContainer'),
      restaurant: restaurant.restaurant,
    });
  },
};

export default Detail;
