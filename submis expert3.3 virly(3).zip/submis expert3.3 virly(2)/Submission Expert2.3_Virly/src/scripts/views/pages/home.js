import RestaurantDbSource from '../../data/restaurant-source';
import { createRestaurantItemTemplate } from '../templates/template-restaurant';

const Home = {
  async render() {
    return `
    <div class="hero"
      <picture>
        <source media="(max-width: 600px)" srcset="/images/hero-image_4-small.jpg">
        <img src="/images/hero-image_4-large.jpg" 
            alt="hero">
        </picture>
      <div class="heroinner">
        <p class="herotitle">Let's Explore Indonesian Delicious Food Recommendations✨</p>
      </div> 
    </div>
  
  <section class="content">
    <h2 class="list-title">-------List Restaurant-------</h2>
    <div id="list" class="list-restaurant">
    </section>
      `;
  },

  async afterRender() {
    const restaurants = await RestaurantDbSource.restaurants();
    const restaurantsContainer = document.querySelector('#list');
    restaurants.forEach((restaurant) => {
      restaurantsContainer.innerHTML += createRestaurantItemTemplate(restaurant);
    });
  },
};

export default Home;
