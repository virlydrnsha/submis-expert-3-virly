import FavoriteRestaurant from '../../data/favorite-restaurant';
import { createRestaurantItemTemplate } from '../templates/template-restaurant';

const Favorite = {
  async render() {
    return `
    <a href="#content" class="skip-link">Skip to content</a>
    
    <section class="content">
    <h2 class="list-title"> List Favorite Restaurant </h2>
    <div id="list" class="list-restaurant">
    </section>
      `;
  },

  async afterRender() {
    const restaurants = await FavoriteRestaurant.getAllRestaurants();
    const restaurantsContainer = document.querySelector('#list');
    restaurants.forEach((restaurant) => {
      restaurantsContainer.innerHTML += createRestaurantItemTemplate(restaurant);
    });
  },
};
export default Favorite;
